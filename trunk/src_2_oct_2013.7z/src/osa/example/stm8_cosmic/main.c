/* MAIN.C file
 * 
 * Copyright (c) 2002-2005 STMicroelectronics
 */


main()
{
	while (1);
}