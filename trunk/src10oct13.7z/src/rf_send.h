#ifndef _RF_SEND_H_
#define _RF_SEND_H_

#include "board.h"

void RF_Send(u8*, u8);

#endif