#ifndef _7SEG_H_
#define _7SEG_H_

#include "board.h"

void SevenSegOut(u16);
void SevenSegRefresh(void);
void SevenSegInit(void);

#endif