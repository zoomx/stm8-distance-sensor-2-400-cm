#ifndef _CYCLIC_H_
#define _CYCLIC_H_

#include "board.h"
#include "cyclic_conf.h"

void Cyclic_tick(void);
void Cyclic_Start(void);

#endif