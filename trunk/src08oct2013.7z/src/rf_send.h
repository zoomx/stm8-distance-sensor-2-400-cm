#ifndef _DS18B20_H_
#define _DS18B20_H_

#include "board.h"

void RF_Send(u8*, u8);

#endif