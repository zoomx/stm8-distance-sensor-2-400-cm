#include "board.h"
#include "delay.h"

void RF_Send(u8* data, u8 size)
{
  u8 i, j, mask;
  u8 tmp, l_size;
  /* Send 3 0xFF bytes for receiver gain adjustment before sending the start pulse */
    for(i=0; i<3;i++)
      for(j=0;j<8;j++)
      {
        DELAY_US(RFDELAY_350US);
        RFSEND_HIGH();
        DELAY_US(RFDELAY_400US);
        RFSEND_LOW();
      }
      
    /* Send start pulse - 1250us */
    DELAY_US(RFDELAY_850US);
    RFSEND_HIGH();
    DELAY_US(RFDELAY_400US);
    RFSEND_LOW();
    
    /* Send data bytes */
    l_size = size;
    for(i=0; i<l_size; i++)
    {
      tmp = data[i];
      mask = 0x80;
      for(j=0; j<8; j++)
      {
        if(data[i] & mask)
        {
          //send 1 - 750uS wide
          DELAY_US(RFDELAY_350US);
          RFSEND_HIGH();
          DELAY_US(RFDELAY_400US);
          RFSEND_LOW();
        }
        else
        {
          //send 0 - 500uS wide
          DELAY_US(RFDELAY_100US);
          RFSEND_HIGH();
          DELAY_US(RFDELAY_400US);
          RFSEND_LOW();
        }
        mask >>= 1;
      }
    }
}
//-----------------------------------------------------------------------------