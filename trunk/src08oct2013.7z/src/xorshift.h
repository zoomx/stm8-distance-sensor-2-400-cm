#ifndef _SOFTI2C_H
#define _SOFTI2C_H

#include "board.h"

u32 xorshift32(u32);

#endif