#ifndef _RFM70_H_
#define _RFM70_H_

#include <stdio.h>
#include "stm32f10x.h"
#include <stdio.h>
#include "board.h"


//************************RFM function parameter constants********************************//
#define WITH_ACK     0x01 // parameter for sendPayload(..): send with ack expectation
#define NO_ACK       0x00 // parameter for sendPayload(..): send without ack expectation
#define MODE_PTX     0x00 // parameter for setMode(mode): set to transmitter
#define MODE_PRX     0x01 // parameter for setMode(mode): set to receiver
#define EN_AA        0x01 // parameter for configRxPipe(..): enable pipe auto ack
#define NO_AA        0x00 // parameter for configRxPipe(..): disable pipe auto ack
#define TX_DPL       0x01 // parameter for configTxPipe(..): enable dynamic payload for PTX
#define TX_SPL       0x00 // parameter for configTxPipe(..): enable static payload for PTX
#define CRC0         0x00 // parameter for configCRC(crc): disable CRC
#define CRC1         0x01 // parameter for configCRC(crc): 1 byte CRC
#define CRC2         0x02 // parameter for configCRC(crc): 2 byte CRC
#define MBPS1        0x01 // parameter for configSpeed(speed): 1Mbps
#define MBPS2        0x02 // parameter for configSpeed(speed): 2Mbps
#define DBMM10       0x00 // parameter for confRfPwr(pwr): -10 dBm
#define DBMM5        0x01 // parameter for confRfPwr(pwr): -5 dBm
#define DBM0         0x02 // parameter for confRfPwr(pwr): 0 dBm
#define DBM5         0x03 // parameter for confRfPwr(pwr): +5 dBm
#define ADR_WIDTH3   0x03 // parameter for confAdrWidth(width): 3 byte
#define ADR_WIDTH4   0x03 // parameter for confAdrWidth(width): 4 byte
#define ADR_WIDTH5   0x03 // parameter for confAdrWidth(width): 5 byte
#define PWR_OFF      0x00 // parameter for setPower(pwr): off
#define PWR_ON       0x01 // parameter for setPower(pwr): on




//************************RFM Definitions************************************************//
#define RFM70_MAX_PACKET_LEN 32// max value is 32
#define RFM70_BEGIN_INIT_WAIT_MS 1000 // pause before Init Registers
#define RFM70_END_INIT_WAIT_MS 100 // pause after init registers
#define RFM70_CS_DELAY 1 // wait ms after CS pin state change



//************************RFM COMMAND and REGISTER****************************************//
// SPI(RFM70) commands
#define RFM70_CMD_READ_REG 0x00 // Define read command to register
#define RFM70_CMD_WRITE_REG 0x20 // Define write command to register
#define RFM70_CMD_RD_RX_PLOAD 0x61 // Define RX payload command
#define RFM70_CMD_WR_TX_PLOAD 0xA0 // Define TX payload command
#define RFM70_CMD_FLUSH_TX 0xE1 // Define flush TX register command
#define RFM70_CMD_FLUSH_RX 0xE2 // Define flush RX register command
#define RFM70_CMD_REUSE_TX_PL 0xE3 // Define reuse TX payload register command
#define RFM70_CMD_W_TX_PAYLOAD_NOACK 0xb0 // Define TX payload NOACK command
#define RFM70_CMD_W_ACK_PAYLOAD 0xa8 // Define Write ack command
#define RFM70_CMD_ACTIVATE 0x50 // Define feature activation command
#define RFM70_CMD_RX_PL_WID 0x60 // Define received payload width command
#define RFM70_CMD_NOP_NOP 0xFF // Define No Operation, might be used to read status register

// SPI(RFM70) registers(addresses)
#define RFM70_REG_CONFIG 0x00 // 'Config' register address
#define RFM70_REG_EN_AA 0x01 // 'Enable Auto Acknowledgment' register address
#define RFM70_REG_EN_RXADDR 0x02 // 'Enabled RX addresses' register address
#define RFM70_REG_SETUP_AW 0x03 // 'Setup address width' register address
#define RFM70_REG_SETUP_RETR 0x04 // 'Setup Auto. Retrans' register address
#define RFM70_REG_RF_CH 0x05 // 'RF channel' register address
#define RFM70_REG_RF_SETUP 0x06 // 'RF setup' register address
#define RFM70_REG_STATUS 0x07 // 'Status' register address
#define RFM70_REG_OBSERVE_TX 0x08 // 'Observe TX' register address
#define RFM70_REG_CD 0x09 // 'Carrier Detect' register address
#define RFM70_REG_RX_ADDR_P0 0x0A // 'RX address pipe0' register address
#define RFM70_REG_RX_ADDR_P1 0x0B // 'RX address pipe1' register address
#define RFM70_REG_RX_ADDR_P2 0x0C // 'RX address pipe2' register address
#define RFM70_REG_RX_ADDR_P3 0x0D // 'RX address pipe3' register address
#define RFM70_REG_RX_ADDR_P4 0x0E // 'RX address pipe4' register address
#define RFM70_REG_RX_ADDR_P5 0x0F // 'RX address pipe5' register address
#define RFM70_REG_TX_ADDR 0x10 // 'TX address' register address
#define RFM70_REG_RX_PW_P0 0x11 // 'RX payload width, pipe0' register address
#define RFM70_REG_RX_PW_P1 0x12 // 'RX payload width, pipe1' register address
#define RFM70_REG_RX_PW_P2 0x13 // 'RX payload width, pipe2' register address
#define RFM70_REG_RX_PW_P3 0x14 // 'RX payload width, pipe3' register address
#define RFM70_REG_RX_PW_P4 0x15 // 'RX payload width, pipe4' register address
#define RFM70_REG_RX_PW_P5 0x16 // 'RX payload width, pipe5' register address
#define RFM70_REG_FIFO_STATUS 0x17 // 'FIFO Status Register' register address
#define RFM70_REG_DYNPD 0x1c // 'Enable dynamic payload length' register address
#define RFM70_REG_FEATURE 0x1d // 'Feature' register address

//interrupt status
#define RFM70_IRQ_STATUS_RX_DR 0x40 // Status bit RX_DR IRQ
#define RFM70_IRQ_STATUS_TX_DS 0x20 // Status bit TX_DS IRQ
#define RFM70_IRQ_STATUS_MAX_RT 0x10 // Status bit MAX_RT IRQ

#define RFM70_IRQ_STATUS_TX_FULL 0x01

//FIFO_STATUS
#define RFM70_FIFO_STATUS_TX_REUSE 0x40
#define RFM70_FIFO_STATUS_TX_FULL 0x20
#define RFM70_FIFO_STATUS_TX_EMPTY 0x10

#define RFM70_FIFO_STATUS_RX_FULL 0x02
#define RFM70_FIFO_STATUS_RX_EMPTY 0x01

//Register bit masks
//#define RFM70_CONFIG_MASK_RX_DR 0x01 // Mask interrupt caused by RX_DR 1 not reflect, 0 reflect on IRQ pin
//#define RFM70_CONFIG_MASK_TX_DS 0x02 // Mask interrupt caused by RX_DS 1 not reflect, 0 reflect on IRQ pin
//#define RFM70_CONFIG_MASK_MAX_RT 0x04 // Mask interrupt caused by MAX_RT 1 not reflect, 0 reflect on IRQ pin
//#define RFM70_CONFIG_EN_CRC 0x08 // Mask interrupt caused by MAX_RT 1 not reflect, 0 reflect on IRQ pin
// ...
#define RFM70_CD_CD 0x01 // 1 = Carrier detect

#define RFM70_PIN_PRIM_RX 0x01
#define RFM70_PIN_POWER 0x02

//************************RFM SPI Constants****************************************//
#define RFM77_SPI_CLOCK_DIV4 0x00
#define RFM77_SPI_CLOCK_DIV16 0x01
#define RFM77_SPI_CLOCK_DIV64 0x02
#define RFM77_SPI_CLOCK_DIV128 0x03
#define RFM77_SPI_CLOCK_DIV2 0x04
#define RFM77_SPI_CLOCK_DIV8 0x05
#define RFM77_SPI_CLOCK_DIV32 0x06
#define SPI_CLOCK_MASK 0x03 // SPR1 = bit 1, SPR0 = bit 0 on SPCR
#define SPI_2XCLOCK_MASK 0x01 // SPI2X = bit 0 on SPSR

#define RFM77_DEFAULT_SPI_CLOCK_DIV RFM77_SPI_CLOCK_DIV2


//************************RFM Debug Tokens******************************************//
#define RFM70_DEBUG_WRONG_CHIP_ID 0x01
#define RFM70_DEBUG_FIFO_FULL 0x02
#define RFM70_SHOW_REGISTERS 0x03

//************************RFM class declaraions*************************************//

  void setPinState(uint32_t pin, uint8_t state);

  void delayMs(vu32 ms);

  void initSPI(uint8_t cs, uint8_t clk_div);
  void initHardware(uint8_t ce, uint8_t irq);
  void initRegisters(void);

  uint8_t transmitSPI(uint8_t val);

  void writeRegPgmBuf(uint8_t * cmdbuf, uint8_t len);
  void writeRegCmdBuf(uint8_t cmd, uint8_t * buf, uint8_t len);

  void setModeRX(void);
  void setModeTX(void);

  void Begin(uint8_t irq);
  void setMode(uint8_t mode); // 0=MODE_PTX, 1=MODE_PRX
  void setChannel(uint8_t cnum);
  uint8_t getChannel(void);
  uint8_t sendPayload2(uint8_t * payload, uint8_t len); // No ACK expected
  uint8_t sendPayload3(uint8_t * payload, uint8_t len, uint8_t toAck); // choose 0=nAck, 1=AckRequest
  uint8_t sendAckPayload(uint8_t * payload, uint8_t len); // prx can put payload in txFIFO to be sent with ACK
  uint8_t receivePayload(uint8_t *payload);
  void flushTxFIFO();
  void flushRxFIFO();

  // Advanced

  uint8_t getMode(void); // 0=MODE_PTX, 1=MODE_PRX
  uint8_t getCarrierDetect(void);
  uint8_t getPLC(void);
  uint8_t getARC(void);
  void setPower(uint8_t pwr); // PWR_ON | PWR_OFF = 1|0
  uint8_t rxDataReceived(); // >0 = recieved on pie 1..6
  uint8_t txDataSent(); // 1 = sent a NO_ACK pkg or received an ACK pkg
  uint8_t txTimeout(); // 1 = timeout
  uint8_t txFIFOFull(); // 1 = full 0 = available
  uint8_t txFIFOEmpty(); // 1 = empty 0 = available
  uint8_t rxFIFOFull(); // 1 = full 0 = available
  uint8_t rxFIFOEmpty(); // 1 = empty 0 = available
  void confIRQ(uint8_t irq_pin, uint8_t reflectTX_DS, uint8_t reflectRX_DR, uint8_t reflectMAX_RT);
  void cliAll();
  void cliRxDr();
  void cliTxDs();
  void cliTimeout();

  // Expert
  uint8_t configRxPipe(uint8_t nr, uint8_t * adr, uint8_t plLen, uint8_t ena_aa); // pipe=1..6 plLen=0=>DPL, plLen>0=>SPL(plLen). ena_aa = EN_AA | NO_AA
  void enableRxPipe(uint8_t nr); // pipe=1..6
  void disableRxPipe(uint8_t nr); // pipe=1..6
  void configTxPipe(uint8_t * adr, uint8_t pltype); // plType = TX_SPL || TX_DPL = 0|1
  void configCRC(uint8_t crc); // crc= CRC0 | CRC1 | CRC2 = 0..2
  void configARD(uint8_t ard); // 0..15 * 250us
  void configARC(uint8_t arc); // 0..15 times
  void configSpeed(uint8_t speed); // MPPS1 | MBPS2 = 1 | 2
  void configRfPower(uint8_t pwr); // 0=-10dBm, 1=-5dBm, 2=0dBM, 3=+5dBm
  void configLnaGain(uint8_t gain); // 0 = low , 1 = high
  void confAddrWidth(uint8_t width); // ADDR_WIDTH3..5 = 3..5
  void debug(uint8_t token);

  // Expert: Hardware access
  uint8_t readRegVal(uint8_t cmd);
  void readRegBuf(uint8_t reg, uint8_t * buf, uint8_t len);
  void writeRegVal(uint8_t cmd, uint8_t val);
  void selectBank(uint8_t bank);


#endif



//TODOs
// debug(); // needs an output stream and a token. Documentation for tokens.
// streaming interface and examples
// check star configuration and write example for that
// multiple RFM at one avr
// error handler for FIFO full on Tx
// transmission quality indicator
// CSMA/AD example
// Carrier detect signal does not work
// ard does not work
// check adrlen3 with setrxadr
