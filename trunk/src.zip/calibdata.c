#include "board.h"

extern const CAL;

struct 
{
  u8 AddressOutOfRAnge : 1;
  u8 CRCDoNotMatch : 1;
}Calib_Status = {0, 0};

#define SIZEOFCAL (u8)13
#define CAL_Base_Address (u16)(&CAL)
#define CAL_MAX_Address  (u16)(CAL_Base_Address + SIZEOFCAL)

void CalibData_Update(u16 address, u8* data, u8 size)
{
  u8 i, CHKSUM = 0;
  /* Unlock FLASH */
  FLASH->PUKR = FLASH_RASS_KEY1;
  FLASH->PUKR = FLASH_RASS_KEY2;
  
  //Calculate CheckSum for received data and compare it to the received CheckSum
  for(i = 0; i < size; i++)
  {
    CHKSUM += *data;
    data++;
  }
  CHKSUM = ~CHKSUM;
  if(CHKSUM != *(data)) 
  {
    Calib_Status.CRCDoNotMatch = 1;
    /* Lock FLASH */
    FLASH->IAPSR &= (uint8_t)FLASH_MEMTYPE_PROG;
    return;
  }
  data -= size;
  
  while(size > 0)
  {
    if(address >= CAL_Base_Address && address < CAL_MAX_Address)
    {
      *(PointerAttr u8*) (u16)address = *data;
      data++;
      address++;
      size--;
    }
    else
    {
      Calib_Status.AddressOutOfRAnge = 1;
      /* Lock FLASH */
      FLASH->IAPSR &= (uint8_t)FLASH_MEMTYPE_PROG;
      return;
    }
  }
  
  
}