#ifndef _DISPLAY_CONF_H_
#define _DISPLAY_CONF_H_

#include "board.h"
 
#define SCREEN_NUM   (u8)3
 
#endif