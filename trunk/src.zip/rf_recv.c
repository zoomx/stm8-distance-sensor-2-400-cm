#include "board.h"

#define BYTES_TO_RCV  (u8)10

u8 rxdat[BYTES_TO_RCV];  // (global var) holds received RF bytes

//=============================================================================
//   RECEIVE_RF_PACKET
//=============================================================================
void receive_rf_packet(void)
{
  //-------------------------------------------------------
  // This function receives an RF packet of bytes in my pulse period
  // encoded format. The packet must have 10 valid contiguous bytes
  // or the function will not exit. There is no timeout feature, but could be added.
  // global variable; unsigned char rxdat[10] holds the 10 byte result.
  // Note! TMR0 is running at 500kHz, so 200uS = 100 TMR0 ticks
  //-------------------------------------------------------
  u8 rrp_data;
  u8 rrp_period;
  u8 rrp_bits;
  u8 rrp_bytes;

  rrp_bytes = 0;
  while(rrp_bytes < BYTES_TO_RCV)   // loop until it has received 10 contiguous RF bytes
  {
    //-----------------------------------------
    // wait for a start pulse >200uS
    while(1)
    {
      //while(!PORTC.F7);             // wait for input / edge
      //while(PORTC.F7);              // wait for input \ edge
      //rrp_period = TMR0L;           // grab the pulse period!
      //TMR0L = 0;                    // and ready to record next period
      if(rrp_period < 100) rrp_bytes = 0;   // clear bytecount if still receiving noise
      else break;                   // exit if pulse was >200uS
    }

    //-----------------------------------------
    // now we had a start pulse, record 8 bits
    rrp_bits = 8;
    while(rrp_bits)
    {
      //while(!PORTC.F7);         // wait for input / edge
      //while(PORTC.F7);          // wait for input \ edge
      //rrp_period = TMR0L;           // grab the pulse period!
      //TMR0L = 0;                    // and ready to record next period

      if(rrp_period >= 100) break;  // if >=200uS, is unexpected start pulse!

      if(rrp_period >= 61) rrp_data |= 0x01;    // 61 = 122uS  set LSB bit

      rrp_data <<= 1;               // save the good bit into rrp_data
      rrp_bits--;                   // and record 1 more good bit done
    }

    //-----------------------------------------
    // gets to here after 8 good bits OR after an error (unexpected start pulse)
    if(rrp_bits)      // if error
    {
      rrp_bytes = 0;  // reset bytes, must run from start of a new packet again!
    }
    else              // else 8 good bits were received
    {
      //rxdat[rrp_bytes] = rrp_data;  // so save the received byte into array
      rrp_bytes++;                  // record another good byte was saved
    }
  }
}
//-----------------------------------------------------------------------------