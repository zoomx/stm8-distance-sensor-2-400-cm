#ifndef _XORSHIFT32_H
#define _XORSHIFT32_H

#include "board.h"

u32 xorshift32(u32);

#endif