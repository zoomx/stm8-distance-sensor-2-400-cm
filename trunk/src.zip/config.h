#ifndef _CONFIG_H_
#define _CONFIG_H_

void Config(void);

#endif