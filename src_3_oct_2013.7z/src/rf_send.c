#include "board.h"

//=============================================================================
//   SEND_RF_BYTE
//=============================================================================
void send_rf_byte(unsigned char txdat)
{
  //-------------------------------------------------------
  // This is a pulse period encoded system to send a byte to RF module.
  // Bits are sent MSB first. Each byte sends 9 pulses (makes 8 periods).
  // Timing;
  //   HI pulse width; always 80uS
  //   0 bit, LO width; 20uS (total 0 bit pulse period 100uS)
  //   1 bit, LO width; 70uS (total 1 bit pulse period 150uS)
  //   space between bytes, LO width; 170uS (total space period 250uS)
  // (timings tested with 20MHz xtal PIC 18F, no pll)
  //-------------------------------------------------------
  unsigned char tbit;

  // make 250uS start bit first
  //Delay_uS(170);      // 170uS LO
  //LATC.F6 = 1;
  //Delay_uS(80-1);     // 80uS HI
  //LATC.F6 = 0;

  // now loop and send 8 bits
  for(tbit=0; tbit<8; tbit++)
  {
    //Delay_uS(20-1);             // default 0 bit LO period is 20uS
    //if(txdat.F7) Delay_uS(50);  // increase the LO period if is a 1 bit!
    //LATC.F6 = 1;
    //Delay_uS(80-1);             // 80uS HI pulse
    //LATC.F6 = 0;
    //txdat <<= 1;                // roll data byte left to get next bit
  }
}
//-----------------------------------------------------------------------------